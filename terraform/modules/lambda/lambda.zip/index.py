import json
import boto3
import os

def handler(event, context):
    print("Image received:", event['Records'][0]['s3']['object']['key'])
    
    # Log the full event for debugging
    print("Event:", json.dumps(event))
    
    return {
        'statusCode': 200,
        'body': json.dumps('Image processed successfully')
    }
